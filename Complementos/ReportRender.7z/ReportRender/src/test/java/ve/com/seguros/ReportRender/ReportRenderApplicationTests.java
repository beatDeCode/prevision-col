package ve.com.seguros.ReportRender;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportRenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
