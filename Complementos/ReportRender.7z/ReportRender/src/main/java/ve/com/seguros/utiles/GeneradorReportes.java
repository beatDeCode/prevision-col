package ve.com.seguros.utiles;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.ooxml.JRXlsxExporter;
import net.sf.jasperreports.export.SimpleExporterInput;
import net.sf.jasperreports.export.SimpleOutputStreamExporterOutput;
import net.sf.jasperreports.export.SimpleXlsxReportConfiguration;

@Service
public class GeneradorReportes {
	@Autowired
    protected DataSource dataSource;
	
	public ResponseEntity<Resource> fnGenerarReportes(String pNombreCompilado, String pParametros) {
		Path vRuta = null;
	    ByteArrayResource vArchivoRetorno = null;
	    File archivoExportado=null;
	    String vNombreDelReporte="";
	    try {
	    	SimpleDateFormat vFormatoFecha=new SimpleDateFormat("dd-MM-yy");
	    	String vFechaExtraccion=vFormatoFecha.format(new Date());
	    	
	    	HashMap<String, Object> vParametrosReporte= new HashMap<String, Object>();
	    	String [] vArray=new String[pParametros.split("-").length];
	    	vArray=pParametros.split("-");
	    	/*for(int indice=0;indice<vArray.length;indice++) {
	    		if( (indice+1)%2==0 ) {
	    			vParametrosReporte.put(vArray[indice-1], vArray[indice]);
	    		}
	    	}*/
	    	vParametrosReporte.put("param1", 18);
	    	Connection connection = dataSource.getConnection(	);
	    	JasperPrint vImpresionReporte = JasperFillManager.fillReport(
	    			pNombreCompilado+".jasper", 
	    			vParametrosReporte,
	    			connection);
	    	vNombreDelReporte=pNombreCompilado+".pdf";
	    	
			/*SimpleXlsxReportConfiguration vConfiguracionDelReporte= new SimpleXlsxReportConfiguration();
			vConfiguracionDelReporte.setDetectCellType(true);
			vConfiguracionDelReporte.setOnePagePerSheet(true);
			vConfiguracionDelReporte.setIgnoreCellBackground(false);
			vConfiguracionDelReporte.setWhitePageBackground(true);
			File vArchivoSalida= new File(
					vNombreDelReporte);
			JRXlsxExporter vExportadorDeArchivo= new JRXlsxExporter();
			vExportadorDeArchivo.setExporterInput(new SimpleExporterInput(vImpresionReporte));
			vExportadorDeArchivo.setExporterOutput(new SimpleOutputStreamExporterOutput(vArchivoSalida));
			vExportadorDeArchivo.setConfiguration(vConfiguracionDelReporte);
			vExportadorDeArchivo.exportReport();*/
	    	
			JRPdfExporter vExportadorDeArchivo = new JRPdfExporter();
			JasperExportManager.exportReportToPdfFile(vImpresionReporte,
					vNombreDelReporte);
			vExportadorDeArchivo.setExporterInput(new SimpleExporterInput(vImpresionReporte));
			vExportadorDeArchivo.setExporterOutput(new SimpleOutputStreamExporterOutput(
					new File(vNombreDelReporte)));
			vExportadorDeArchivo.exportReport();
	    	archivoExportado=new File(vNombreDelReporte);
	    	
	    	
	    	connection.close();
	    	
	    	vRuta = Paths.get(archivoExportado.getAbsolutePath());
	    	vArchivoRetorno = new ByteArrayResource(Files.readAllBytes(vRuta));
		} catch (Exception e) {
			e.printStackTrace();
		}
	    return ResponseEntity.ok()
	    		.header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename="+vNombreDelReporte )
	            .contentLength(archivoExportado.length())
	            .contentType(MediaType.APPLICATION_OCTET_STREAM)
	            .body(vArchivoRetorno);
		
	} 
}
