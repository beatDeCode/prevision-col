package ve.com.seguros.ReportRender;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"ve.com.seguros.utiles","ve.com.seguros.restServices"})
public class ReportRenderApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(ReportRenderApplication.class, args);
	}

}
