package ve.com.seguros.restServices;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import ve.com.seguros.utiles.GeneradorReportes;

@RestController
public class RestServices {
	@Autowired
	private GeneradorReportes generadorReportes;
	
	@GetMapping("sgd.reportes/{pNombreArchivo}/{pParametros}")
	public ResponseEntity<Resource> fnSolicitudReporte(
			@PathVariable(value = "pNombreArchivo") String pNombreArchivo,
			@PathVariable(value = "pParametros") String pParametros){
		ResponseEntity<Resource> retorno=generadorReportes.fnGenerarReportes(pNombreArchivo, pParametros);
		return retorno;
	}
}
